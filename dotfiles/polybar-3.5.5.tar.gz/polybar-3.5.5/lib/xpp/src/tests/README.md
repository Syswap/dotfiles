Just a couple of experiments to try out concepts, language features, ideas.
Might or might not compile, run or crash, etc.
